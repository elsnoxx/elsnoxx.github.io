from colorama import Fore

def zobraz_menu(vybrana_volba=None):
    """
    Funkce zobrazí menu s možnostmi pro uživatele. Pokud je zadaná volba, zvýrazní ji v menu.

    :param vybrana_volba: Volitelný argument, číslo volby, která má být zvýrazněna.
    """
