cenaJablka = 28
cenaBanany = 40

while True:

    print("Menu ovoce")
    print("1 - Jablka")
    print("2 - Banany")
    print("0 - Konec")
    
    vyber = int(input("Zadej vyber ovoce: "))

    if vyber == 0:
        break

    hmotnost = int(input("Zadej hmotnost v gramech: "))

    if vyber == 1:
        cena = (hmotnost / 1000) * cenaJablka
        print("Cena jablek je {0}".format(cena))
    if vyber == 2:
        cena = (hmotnost / 1000) * cenaBanany
        print("Cena bananu je {0}".format(cena))
    