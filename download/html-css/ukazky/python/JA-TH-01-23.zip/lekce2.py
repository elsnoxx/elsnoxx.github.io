import turtle

zelva = turtle.Turtle()

okno = turtle.Screen()

zelva.shape("turtle")
turtle.bgcolor("white")
zelva.speed(1)

while 1:
    zelva.pensize(10)
    zelva.pencolor("red")
    zelva.forward(50)
    zelva.penup()
    zelva.pendown()
    zelva.forward(50)
    zelva.left(90)
    zelva.circle(50)


okno.exitonclick()

