import random


nahodne_cislo = random.randint(0, 10)

if nahodne_cislo % 2 == 0:
    print("Cislo je sude -> {0}".format(nahodne_cislo))
else:
    print("Cislo je liche -> {0}".format(nahodne_cislo))


# podminka - vypise jestli je cislo mensi nez 5 a nebo je vetsi nez 5

if nahodne_cislo > 5:
    print("cislo je vetsi nez 5")
if nahodne_cislo < 5:
    print("cislo je mensi nez 5")
if nahodne_cislo == 5:
    print("cislo je 5")






