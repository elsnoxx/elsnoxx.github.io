import turtle 
import time

window = turtle.Screen()
turtle = turtle.Turtle()


while 1:
    turtle.shape("turtle")
    turtle.speed(10)
    turtle.pensize(1)
    for i in range(360):
        turtle.forward(i)
        turtle.left(59)
    time.sleep(2)
    turtle.clear()
    turtle.reset()


window.exitonclick()