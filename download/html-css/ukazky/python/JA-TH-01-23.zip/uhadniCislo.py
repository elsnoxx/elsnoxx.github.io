import random

while True:
    print("Hra se načítá a generuje se nahodne číslo, k hádání.")
    hadaneCislo = random.randint(0, 10)
    print("Hotovo. Hra začíná.")
    pokus = 0
    while True:
        
        vstup = int(input("Zadej číslo: "))

        if pokus == 3:
            print("Prohral jsi")
            break

        if vstup == hadaneCislo:
            print("Vyhrál jsi hádané číslo je {0}".format(hadaneCislo))
        else:
            if vstup > hadaneCislo:
                print("Špatně hádané číslo je menší.")
                pokus += 1

            else:
                print("Špatně hádané číslo je větší.")
                pokus += 1