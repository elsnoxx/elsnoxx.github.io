import turtle 
import time

window = turtle.Screen()
turtle = turtle.Turtle()
turtle.shape("turtle")
turtle.speed(10)
turtle.pensize(3)

while True:
    turtle.shape("turtle")
    turtle.speed(2)
    turtle.pensize(2)

    # obdelnik
    turtle.forward(150)
    turtle.right(90)
    turtle.circle(20)
    turtle.left(180)

    turtle.forward(75)
    turtle.right(180)
    turtle.circle(20)
    turtle.left(270)

    turtle.forward(150)
    turtle.right(90)
    turtle.circle(20)
    turtle.left(180)

    turtle.forward(75)
    turtle.right(180)
    turtle.circle(20)
    turtle.left(270)
    
    time.sleep(2)
    turtle.clear()
    turtle.reset()


# turtle.forward(150)
# turtle.right(90)
# turtle.circle(20)
# turtle.left(180)

# turtle.forward(75)
# turtle.right(180)
# turtle.circle(20)
# turtle.left(270)


window.exitonclick()