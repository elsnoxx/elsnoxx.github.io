print("Ahoj svete")

jmeno = "Richard"
vek = 23





jmeno = input("Zadej sve jmeno: ")
vek = int(input("Zadej svuj vek: "))

print("Ahoj, jmenuji se {0} a je mi {1} let".format(jmeno, vek))