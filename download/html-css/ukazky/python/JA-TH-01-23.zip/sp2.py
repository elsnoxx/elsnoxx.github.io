import random

nahodne_cislo = random.randint(0,10)

while True:
    vstup = int(input("Zadej cislo v rozmezi 0 az 10: "))

    if nahodne_cislo == vstup:
        print("Stejne cisla")
        break
    else:
        if nahodne_cislo > vstup:
            print("Mensi")
        if nahodne_cislo < vstup:
            print("Vetsi")
            
print("konec")